package jp.enpit.cloud.eventspiral.view;

public class AbstractForm extends ValidatedBean implements Form {

}
