package jp.enpit.cloud.eventspiral.view;

public interface Form {
    public boolean validate() throws TEMValidationException;

}
