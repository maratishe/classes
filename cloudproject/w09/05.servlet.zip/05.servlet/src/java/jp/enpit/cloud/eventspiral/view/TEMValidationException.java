package jp.enpit.cloud.eventspiral.view;

/**
 * UC: ログインする
 * @author fukuyasu
 *
 */
public class TEMValidationException extends TEMViewException {

	private static final long serialVersionUID = 4214304664949192996L;

	public TEMValidationException (String message) {
		super(message);
	}

}
