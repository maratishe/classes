package jp.enpit.cloud.eventspiral.view;

/**
 * UC: ログインする
 * @author takata
 *
 */
public abstract class AbstractEntity extends ValidatedBean implements Entity {

}
