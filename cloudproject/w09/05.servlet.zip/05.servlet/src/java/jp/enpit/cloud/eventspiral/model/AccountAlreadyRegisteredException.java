package jp.enpit.cloud.eventspiral.model;

public class AccountAlreadyRegisteredException extends TEMSystemException {
	private static final long serialVersionUID = 7581760299328703281L;

	public AccountAlreadyRegisteredException(String msg) {
		super(msg);
	}
}
