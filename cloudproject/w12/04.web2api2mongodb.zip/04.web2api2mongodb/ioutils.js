// various utilities
//var callback = null;	// for remote script
function nothing() {}
	
// this object can be used by all in this file
$.ioutils = {};	// log( level, method, fontsize, boxes)
$.ioutils.nolog = true;
$.ioutils.nostats = true;
// if you want to collect stats, you need to implement this interface
$.ioutils.stats = { push: function( h, name, atom) { }}; // { push({ type(file.atom), [ time], [ took], ...}, [ name], [ atom])}
$.ioutils.jsonsession = true; // will send $.io.session with each json request
$.ioutils.callbacktimeout = '6s';
$.ioutils.repeats = 5;

$.bs2i = function( string) { return parseInt( '' + string); }	// string to integer
$.b01 = function( pos, length) {
	var v = 0x01;
	for ( var i = 0; i < length - 1; i++) v = ( v << 1) | 0x01;
	for ( var i = 0; i < ( 32 - pos - length); i++) v = ( ( v << 1) | 0x01) ^ 0x01;
	return v;
}
$.bmask = function( v, pos, length) {
	var mask = $.b01( pos, length);
	return v & mask;
}
$.bhead = function( v, bits) { return $.bmask( v, 0, bits); }
$.btail = function( v, bits) { return $.bmask( v, 32 - bits, bits); }
$.bbitstring = function( number, length, separatelength) { // length from the tail 
	if ( ! length) length = 32; if ( ! separatelength) separatelength = 0;
	var out = ''; var separator = separatelength;
	for ( var i = 0; i < length; i++) {
		var number2 = number & 0x01;
		if ( number2) out = '1' + out;
		else out = '0' + out;
		separator--; if ( separator == 0 && i < length - 1) { out = '.' + out; separator = separatelength; }
		number = number >> 1;
	}
	return out;
}
$.bpack = function( bytes) {	// bytes to string 
    var chars = [];
    for ( var i = 0; i < bytes.length; i += 2) {
	   chars.push( ( ( bytes[ i] & 0xff) << 8) | ( bytes[ i + 1] & 0xff));
    }
    var s = ''; for ( var i = 0; i < chars.length; i++) s+= String.fromCharCode( chars[ i]);
    return s;
}
$.bunpack = function( s) {	// string to bytes
    var bytes = [];
    for ( var i = 0; i < s.length; i++) {
	   var char = s.charCodeAt( i);
	   bytes.push( ( char >> 8) & 0xff);
	   bytes.push( char & 0xff);
    }
    return bytes;
}

// create a new gui component
$.log = function( one, two, three, four, five, six, seven) {
	if ( $.ioutils.nolog) return;
	if ( ! window.console) return;
	if ( ! console) return;
	if ( ! console.log) return;
	// output the log
	if ( ! $.isVoid( seven)) return console.log( one, two, three, four, five, six, seven);
	if ( ! $.isVoid( six)) return console.log( one, two, three, four, five, six);
	if ( ! $.isVoid( five)) return console.log( one, two, three, four, five);
	if ( ! $.isVoid( four)) return console.log( one, two, three, four);
	if ( ! $.isVoid( three)) return console.log( one, two, three);
	if ( ! $.isVoid( two)) return console.log( one, two);
	if ( ! $.isVoid( one)) return console.log( one);
}
$.log2 = function( one, two, three, four, five, six, seven) { // will try to copy objects
	if ( $.ioutils.nolog) return;
	if ( ! window.console) return;
	if ( ! console) return;
	if ( ! console.log) return;
	// untie all arrrays and hashes from their original objects
	if ( ! $.isVoid( one) && ! $.isString( one) && ! $.isNumber( one) && $.hk( one) && $.hk( one).length && ! one.get) one = $.json2h( $.h2json( one));
	if ( ! $.isVoid( two) && ! $.isString( two) && ! $.isNumber( two) && $.hk( two) && $.hk( two).length && ! two.get) two = $.json2h( $.h2json( two));
	if ( ! $.isVoid( three) && ! $.isString( three) && ! $.isNumber( three) && $.hk( three) && $.hk( three).length && ! three.get) three = $.json2h( $.h2json( three));
	if ( ! $.isVoid( four) && ! $.isString( four) && ! $.isNumber( four) && $.hk( four) && $.hk( four).length && ! four.get) four = $.json2h( $.h2json( four));
	if ( ! $.isVoid( five) && ! $.isString( five) && ! $.isNumber( five) && $.hk( five) && $.hk( five).length && ! five.get) five = $.json2h( $.h2json( five));
	if ( ! $.isVoid( six) && ! $.isString( six) && ! $.isNumber( six) && $.hk( six) && $.hk( six).length && ! six.get) six = $.json2h( $.h2json( six));
	if ( ! $.isVoid( seven) && ! $.isString( seven) && ! $.isNumber( seven) && $.hk( seven) && $.hk( seven).length && ! seven.get) seven = $.json2h( $.h2json( seven));
	// output the log
	if ( ! $.isVoid( seven)) return console.log( one, two, three, four, five, six, seven);
	if ( ! $.isVoid( six)) return console.log( one, two, three, four, five, six);
	if ( ! $.isVoid( five)) return console.log( one, two, three, four, five);
	if ( ! $.isVoid( four)) return console.log( one, two, three, four);
	if ( ! $.isVoid( three)) return console.log( one, two, three);
	if ( ! $.isVoid( two)) return console.log( one, two);
	if ( ! $.isVoid( one)) return console.log( one);
}
$.die = function( error) { $.log( error); eval( dierightnow)(); }

// time utilities
$.iotime = function( other) { return ( new Date()).getTime() - ( other ? ( other.getTime ? other.getTime() : other) : 0); }	// epoch time in ms

// local storage shortcuts, set and remove will return the size of m	emory occupied/cleaned
$.LSset = function( key, value) { localStorage.setItem( key, value); return key.length + value.length; } // returns size
$.LSget = function( key) { return localStorage.getItem( key); }
$.LSremove = function( key) { v = localStorage.getItem( key); if ( ! v) return null; localStorage.removeItem( key); return key.length + v.length; }
$.LSclear = function() { C.clear(); }

// canvas related (all input colors are #xxx format: SHORT HEX), corner can be array
$.canvasmake = function( one, fillcolor, fillalpha, strokecolor, strokealpha, width, pos) {
	if ( one && one.length && one.length > 0) { // passed as array
		one = $.lm( one);
		if ( one.length) corner = one.shift();
		if ( one.length) fillcolor = one.shift();
		if ( one.length) fillalpha = one.shift();
		if ( one.length) strokecolor = one.shift();
		if ( one.length) strokealpha = one.shift();
		if ( one.length) width = one.shift();
		if ( one.length) pos = one.shift();
	}
	else corner = one;
	if ( ! corner) corner = 1;
	if ( ! fillcolor) fillcolor = '#fff'; if ( ! fillalpha) fillalpha = 1.0; 
	if ( ! strokecolor) strokecolor = '#fff'; if ( ! strokealpha) strokealpha = 1.0;
	if ( ! pos) pos = 'unshift';
	var info = { corner: corner, pos: pos, canvas: { fillStyle: '', strokeStyle: '', lineWidth: width}};
	var map = { '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'a': 10, 'b': 11, 'c': 12, 'd': 13, 'e': 14, 'f': 15};
	var one = map[ fillcolor.substr( 1, 1)]; one += one * 16;
	var two = map[ fillcolor.substr( 2, 1)]; two += two * 16;
	var three = map[ fillcolor.substr( 3, 1)]; three += three * 16;
	info.canvas.fillStyle = 'rgba( ' + one + ', ' + two + ', ' + three + ', ' + fillalpha + ')';
	one = map[ strokecolor.substr( 1, 1)]; one += one * 16;
	two = map[ strokecolor.substr( 2, 1)]; two += two * 16;
	three = map[ strokecolor.substr( 3, 1)]; three += three * 16;
	info.canvas.strokeStyle = 'rgba( ' + one + ', ' + two + ', ' + three + ', ' + strokealpha + ')';
	return info;
}

// css manipulations
$.rgba2rgb = function( rgba) {
	var split = $.s2l( rgba, ',');
	var split2 = $.s2l( split[ 0], '(');
	return 'rgb( ' + $.strim( split2[ 1]) + ', ' + $.strim( split[ 1]) + ', ' + $.strim( split[ 2]) + ')';
}
$.hex2rgb = function( hex) {
	var map = { '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'a': 10, 'A': 10, 'b': 11, 'B': 11, 'c': 12, 'C': 12, 'd': 13, 'D': 13, 'e': 14, 'E': 14, 'f': 15, 'F': 15};
	var one = map[ hex.substr( 1, 1)]; one += one * 16;
	var two = map[ hex.substr( 2, 1)]; two += two * 16;
	var three = map[ hex.substr( 3, 1)]; three += three * 16;
	return 'rgb( ' + one + ', ' + two + ', ' + three + ')';
}
$.hex2rgba = function( hex, opacity) {
	if ( ! opacity) opacity = 1.0;
	var map = { '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'a': 10, 'A': 10, 'b': 11, 'B': 11, 'c': 12, 'C': 12, 'd': 13, 'D': 13, 'e': 14, 'E': 14, 'f': 15, 'F': 15};
	var one = map[ hex.substr( 1, 1)]; one += one * 16;
	var two = map[ hex.substr( 2, 1)]; two += two * 16;
	var three = map[ hex.substr( 3, 1)]; three += three * 16;
	return 'rgba( ' + one + ', ' + two + ', ' + three + ', ' + opacity + ')';
}
$.rgbagradient = function( stops) {
	var map = { '0': 0, '1': 1, '2': 2, '3': 3, '4': 4, '5': 5, '6': 6, '7': 7, '8': 8, '9': 9, 'a': 10, 'A': 10, 'b': 11, 'B': 11, 'c': 12, 'C': 12, 'd': 13, 'D': 13, 'e': 14, 'E': 14, 'f': 15, 'F': 15};
	var props = {};	// will add stops and colors
	for ( var stop in stops) {
		var color = stops[ stop][ 0];
		var one = map[ color.substr( 1, 1)]; one += one * 16;
		var two = map[ color.substr( 2, 1)]; two += two * 16;
		var three = map[ color.substr( 3, 1)]; three += three * 16;
		props[ stop] = 'rgba( ' + one + ', ' + two + ', ' + three + ', ' + stops[ stop][ 1] + ')';
	}
	return props;
}

// basic functionality
$.isBoolean = function( object) {
	if ( typeof( object) == 'boolean') return true;
	return false;
}
$.isVoid = function( object) {
	if ( object === null || typeof( object) == 'undefined') return true;
	return false;
}
$.isObject = function( object) {
	if ( typeof( object) == 'object' && object !== null) return true;
	return false;
}
$.isArray = function( object) {
	if ( ! $.isObject( object)) return false;
	var keys = $.hk( object);
	if ( object.length && object.length > 0 && $.isNumber( object.length) && object.length == keys.length) return true;
}
$.isString = function( object) {
	if ( typeof( object) == 'string') return true;
	return false;
}
$.isNumber = function( object) {
	if ( typeof( object) == 'number') return true;
	return false;
}
$.isEmptyString = function( object) {
	if ( ! $.isString( object)) return false;
	if ( ! object.length) return true;
	return false;
}

// new namings, same as in PHP lib
$.ttl = function( text, delimiter, base64, skipempty) { // comma is default delimiter
	if ( $.isVoid( text) || ! $.isString( text)) return [];
	if ( ! text.length) return [];
	if ( base64) text = $.s642s( text);
	if ( ! delimiter && delimiter !== '') delimiter = ',';
	var list1 = text.split( delimiter);
	if ( ! skipempty) return list1;
	var list2 = [];
	for ( var i in list1) { 
		var v = list1[ i];
		if ( v == '' || v == ' ' || v == "\n" || v == "\t") continue;
		list2.push( $.trim( v));
	}
	return list2;
}
$.ltt = function( list, delimiter, base64) { 
	if ( ! delimiter && delimiter !== '') delimiter = ',';
	var text = ''; var d = ''; 
	for ( var i in list) { text += d + list[ i]; d = delimiter; }
	if ( base64) return $.s2s64( text);
	return text;
}
$.htt = function( hash, delimiter1, delimiter2, base64, base64keys) { // ,= delimiters
	if ( ! delimiter1) delimiter1 = ',';
	if ( ! delimiter2) delimiter2 = '=';
	var keys = $.hk( hash);
	var values = $.hv( hash);
	if ( ! keys.length) return '';
	var L = [];
	while ( keys.length) {
		var k = keys.shift();
		var v = values.shift();
		if ( base64keys) for ( var i in base64keys) if ( k == base64keys[ i]) v = $.s2s64( v);
		L.push( k + delimiter2 + v);
	}
	var S =  $.l2s( L, delimiter1, base64);
	//$.log( 4, 'H2S [' + S + ']');
	return S;
}
$.tth = function( text, delimiter1, delimiter2, base64, base64keys) { // ,= delimiters
	if ( ! delimiter1) delimiter1 = ',';
	if ( ! delimiter2) delimiter2 = '=';
	var L1 = $.s2l( text, delimiter1, base64);
	var H = {};
	for ( var i in L1) {
		var L2 = $.s2l( L1[ i], delimiter2);
		if ( ! L2 || ! L2.length || L2.length !== 2) continue;
		var k = $.trim( L2.shift()); var v = L2.shift();
		if ( base64keys) for ( var y in base64keys) if ( k == base64keys[ y]) v = $.s642s( v);
		H[ k] = $.trim( v);
	}
	return H;
}
// old namings, some of them are used as are
$.s2l = function( text, delimiter, base64, skipempty) { // comma is default delimiter
	if ( $.isVoid( text) || ! $.isString( text)) return [];
	if ( base64) text = $.s642s( text);
	if ( ! delimiter && delimiter !== '') delimiter = ',';
	var list1 = text.split( delimiter);
	if ( ! skipempty) return list1;
	var list2 = [];
	for ( var i in list1) { 
		var v = list1[ i];
		if ( v == '' || v == ' ' || v == "\n" || v == "\t") continue;
		list2.push( $.trim( v));
	}
	return list2;
}
$.l2s = function( list, delimiter, base64) { 
	if ( ! delimiter && delimiter !== '') delimiter = ',';
	var text = ''; var d = ''; 
	for ( var i in list) { text += d + list[ i]; d = delimiter; }
	if ( base64) return $.s2s64( text);
	return text;
}
$.s2sl = function( text, chunksize) { 	// split string into an array of smaller strings
	var out = [];
	while ( text.length) {
		if ( text.length < chunksize) { out.push( text.substr( 0)); text = ''; }
		else { out.push( text.substr( 0, chunksize)); text = text.substr( chunksize); }
	}
	return out;
}
$.h2json = function( hash, base64, base64keys, singlequotestrings) {
	//$.log( 4, ' : h2json():', hash);
	if ( ! hash) return '';
	var h = $.hm( hash, null, true);
	//$.log( 4, ' : h2json():', h);
	if ( base64keys) for ( var i in base64keys) if ( h[ base64keys[ i]]) h[ base64keys[ i]] = $.s2s64( h[ base64keys[ i]]);
	//$.log( 4, ' : h2json():', h);
	if ( singlequotestrings) for ( var i in h) if ( $.isString( h[ i])) h[ i] = "'" + h[ i] + "'";
	//$.log( 4, ' : h2json():', h);
	var value = $.toJSON( h);
	//$.log( 4, ' : h2json():', value);
	if ( base64) value = $.s2s64( value);
	return value;
}
$.json2h = function( value, base64, base64keys) {
	if ( base64) value = $.s642s( value);
	//$.log( 4, ' JSON2H : decoded value', value);
	//$.log( 4, 'JSON2H : decoded string : ', value);
	var h = $.evalJSON( value);
	if ( base64keys) for ( var i in base64keys) if ( h[ base64keys[ i]]) h[ base64keys[ i]] = $.s642s( h[ base64keys[ i]]);
	return h;
}
$.any2json = function( v, base64) { var v2 = $.toJSON( v); return base64 ? $.s2s64( v2) : v2; }
$.json2any = function ( v, base64) { var v2 = base64 ? $.s642s( v) : v; return v2 && $.isString( v2) ? $.evalJSON( v2) : {};}
$.h2s = function( hash, delimiter1, delimiter2, base64, base64keys) { // ,= delimiters
	if ( ! delimiter1) delimiter1 = ',';
	if ( ! delimiter2) delimiter2 = '=';
	var keys = $.hk( hash);
	var values = $.hv( hash);
	if ( ! keys.length) return '';
	var L = [];
	while ( keys.length) {
		var k = keys.shift();
		var v = values.shift();
		if ( base64keys) for ( var i in base64keys) if ( k == base64keys[ i]) v = $.s2s64( v);
		L.push( k + delimiter2 + v);
	}
	var S =  $.l2s( L, delimiter1, base64);
	//$.log( 4, 'H2S [' + S + ']');
	return S;
}
$.s2h = function( text, delimiter1, delimiter2, base64, base64keys) { // ,= delimiters
	if ( ! delimiter1) delimiter1 = ',';
	if ( ! delimiter2) delimiter2 = '=';
	var L1 = $.s2l( text, delimiter1, base64);
	var H = {};
	for ( var i in L1) {
		var L2 = $.s2l( L1[ i], delimiter2);
		if ( L2.length == 1) continue;
		var k = $.trim( L2.shift()); var v = L2.shift(); while ( L2.length) v += L2.shift(); 
		if ( base64keys) for ( var y in base64keys) if ( k == base64keys[ y]) v = $.s642s( v);
		H[ k] = $.trim( v);
	}
	return H;
}
$.hr = function( one, two, keepEmptyStrings) { // hash replace	
	var hash = {};
	if ( $.isArray( one)) hash = [];	// array case
	for ( var key in one) {
		if ( $.isVoid( two) || $.isVoid( two[ key])) { 
			if ( $.isObject( one[ key])) { 
				hash[ key] = $.hr( one[ key], null, keepEmptyStrings); 
				continue; 
			}
			if ( $.isEmptyString( one[ key]) && ! keepEmptyStrings) continue;
			hash[ key] = one[ key]; 
			continue;
		}
		if ( typeof( one[ key]) !== typeof( two[ key])) { 
			if ( $.isObject( one[ key])) { 
				hash[ key] = $.hr( one[ key], null, keepEmptyStrings); 
				continue; 
			}
			if ( $.isEmptyString( one[ key]) && ! keepEmptyStrings) continue;
			hash[ key] = one[ key];
			continue; 
		}
		if ( $.isObject( one[ key])) { 
			hash[ key] = $.hr( one[ key], two[ key], keepEmptyStrings); 
			continue; 
		}
		if ( ! $.isString( one[ key])) { 
			hash[ key] = two[ key]; 
			continue; 
		} 
		if ( $.isEmptyString( one[ key])) {
			if ( ! two[ key] && ! keepEmptyStrings) continue; // empty strings do not pass
			if ( two[ key] && $.isEmptyString( two[ key]) && ! keepEmptyStrings) continue;
		}
		hash[ key] = two[ key];
	}
	return hash;
}
$.hm = function( one, two, keepEmptyStrings, debug) {	// hash merge
	if ( debug) $.log( 'hashMerge : merging:', one, two);
	var hash = {};
	var keys = [];
	if ( one)  for( var key in one) keys.push( key);
	if ( two) for ( var key in two) if ( ( one && $.isVoid( one[ key])) || ! one) keys.push( key);
	if ( debug) $.log( 'hashMerge : full list of keys:', keys);
	if ( $.isArray( one) || $.isArray( two)) hash = [];
	for ( var i = 0; i < keys.length; i++) {
		var key = keys[ i];
		if ( debug) $.log( 'hashMerge :   working key=', key);
		if ( $.isVoid( two) || $.isVoid( two[ key])) { 
			if ( debug) $.log( 'hashMerge :    either two or two[ key] is void');
			if ( $.isObject( one[ key])) { 
				if ( debug) $.log( 'hashMerge :    one[ key] is object, delv:', one[ key]);
				hash[ key] = $.hm( one[ key], null, keepEmptyStrings, debug); 
				continue; 
			}
			if ( debug) $.log( 'hashMerge :    one[ key] is not object, check for empty string:', one[ key]);
			if ( $.isEmptyString( one[ key]) && ! keepEmptyStrings) continue;
			if ( debug) $.log( 'hashMerge :    one[key] is not empty string, add value:', one[ key]);
			hash[ key] = one[ key]; 
			continue;
		}
		if ( $.isVoid( one) || $.isVoid( one[ key])) { 
			if ( debug) $.log( 'hashMerge :    one or one[key] is void');
			if ( $.isObject( two[ key])) {
				if ( debug) $.log( 'hashMerge :    two[ key] is object, delv:', two[ key]);
				hash[ key] = $.hm( null, two[ key], keepEmptyStrings, debug); 
				continue; 
			}
			if ( debug) $.log( 'hashMerge :    two[key] is not object, check for empty string:', two[ key]);
			if ( $.isEmptyString( two[ key]) && ! keepEmptyStrings) continue;
			if ( debug) $.log( 'hashMerge :    two[key] is not empty string, add key:', two[ key]);
			hash[ key] = two[ key]; 
			continue;
		}
		if ( typeof( one[ key]) !== typeof( two[ key])) {	// one has precedence in clashes 
			if ( $.isObject( one[ key])) { 
				hash[ key] = $.hm( one[ key], null, keepEmptyStrings, debug); 
				continue; 
			}
			if ( $.isEmptyString( one[ key]) && ! keepEmptyStrings) continue;
			hash[ key] = one[ key];
			continue; 
		}
		if ( $.isObject( one[ key])) {	// one still has precedence 
			if ( debug) $.log( 'hashMerge :    one[key] is object:', one[key]);
			hash[ key] = $.hm( one[ key], two[ key], keepEmptyStrings, debug); 
			continue; 
		}
		if ( ! $.isString( one[ key])) {	// precedence to one 
			if ( debug) $.log( 'hashMerge :    one key is not object but is not string:', one[ key]);
			hash[ key] = two[ key]; 
			continue; 
		} 
		if ( debug) $.log( 'hashMerge :    one[key] is definitely string:', one[key]);
		if ( $.isEmptyString( one[ key])) {
			if ( debug) $.log( 'hashMerge :    one[key] is empty string, check two:', one[ key], two[ key]);
			if ( ! two[ key] && ! keepEmptyStrings) continue; // empty strings do not pass
			if ( two[ key] && $.isEmptyString( two[ key]) && ! keepEmptyStrings) continue;
		}
		if ( debug) $.log( 'hashMerge :    adding new key from two[key]:', key, two[key]);
		hash[ key] = two[ key];
	}
	if ( debug) $.log( 'resulting object:', hash);
	return hash;
}
$.hd = function( first, keys) {	// hash delete
	var hash = {};
	for ( var key in first) {
		if ( ! keys) { hash[ key] = first[ key]; continue; }
		var found = false;
		for ( var i = 0; i < keys.length; i++) {
			if ( key == keys[ i]) { found = true; break; }
		}
		if ( found) continue;		// ignore this key
		hash[ key] = first[ key];
	}
	return hash;
}
$.hk = function( hash) { // hash keys
	var list = [];
	for ( var key in hash) list.push( key);
	return list;
}
$.hv = function( hash) { // hash values
	var list = [];
	for ( var key in hash) list.push( hash[ key]);
	return list;
}
$.hrk = function( hash, keys) { 	// hash remove keys
	var out = {}; if ( $.isString( keys)) keys = [ keys];
	for ( var k in hash) {
		var found = false;
		for ( var k2 in keys) if ( keys[ k2] == k) { found = true; break; }
		if ( found) continue;
		out[ k] = hash[ k];
	}
	return out;
}
// string to base64 string
$.s2s64 = function( value) { return btoa( value);  }
$.s642s = function( value) { return atob( value); }
// string > base64 > compress (compressed bytestring is valid javascript string), with callbacks
$.s2s64c = function( value, c, alreadybase64) { // uses fixed base64 dict
	LZWAsync.compress({ input: alreadybase64 ? value : $.s2s64( value), output: c, dict: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="});
}
$.s64c2s = function( value, c, donotunbase64) { // uses fixed base64 dict
	LZWAsync.decompress({ input: value, output: function( v) { eval( c)( donotunbase64 ? v : $.s642s( v))}, dict: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/="});
}
$.sfill = function( s, length, what, tail) { s = '' + s; while ( s.length < length) s = ( tail ? '' : ( what ? what : '0')) + s + ( tail ? ( what ? what : '0') : ''); return s; }
// advanced hash and list functions
$.hlm = function( hl) {
	var h = {};
	for ( var i in hl) for ( key in hl[ i]) h[ key] = hl[ i][ key];
	return h;
}
$.hltl = function( hl, key) {
	var L = [];
	for ( var i in hl) for ( var k in hl[ i]) if ( k == key) L.push( hl[ i][ k]);
	return L;
}
$.hlth = function( hl, kkey, vkey) {
	var H = {};
	for ( var i in hl) H[ hl[ i][ kkey]] = hl[ i][ vkey];
	return H;
}
$.hlf = function( hl, key, value) {
	var hl2 = [];	// return hash after the filter
	for ( var i in hl) {
		if ( key && $.isVoid( hl[ i][ key])) continue;
		if ( key && value && hl[ i][ key] != value) continue;
		hl2.push( hl[ i]);
	}
	return hl2;
}
$.hvak = function( h, donotoverwrite, value) {
	if ( ! value) value = null;
	var h2 = {};
	for ( var k in h) {
		if ( donotoverwrite && h2[ h[ k]]) continue;
		h2[ h[ k]] = value === null ? k : value;
	}
	return h2;
}
$.hl2b64jsonl = function( hl) { 	// hashlist to base64( json) plain text lines
	var out = '';
	for ( var i = 0; i < hl.length; i++) out += $.h2json( hl[ i], true) + "\n";
	return out;
}
$.b64jsonl2hl = function( text) {
	var L = $.s2l( text, "\n");
	var info = []; 
	for ( var i = 0; i < L.length; i++) if ( $.trim( L[ i]).length) info.push( $.json2h( L[ i], true));
	return info;
}
// locates an element in h based on dot-delimited path, returns NULL if fails
$.hpath = function( h, path) { // path can be array, will do the same for each element in the list
	var ks = [ path]; if ( $.isArray( path)) ks = path; var type = $.isArray( path);
	//$.log( 'hpath() : ks : ', ks);
	var vs = [];
	for ( var i = 0; i < ks.length; i++) {
		var L = $.s2l( ks[ i], '.'); var h2 = h;
		while ( L.length) {
			var leg = L.shift();
			if ( ! h2[ leg]) return null;	// failed to find entry on this path
			h2 = h2[ leg];
		}
		vs.push( h2);
	}
	//$.log( 'hpath() : vs : ', vs);
	return type ? vs : vs[ 0];
}
// list
$.lm = function( first, second) {
	var list = [];
	for ( var i = 0; i < first.length; i++) list.push( first[ i]);
	if ( ! second) return list;   
	for ( var i = 0; i < second.length; i++) list.push( second[ i]);
	return list;
}
// sorting
$.lsort = function ( L, bigtosmall) { L.sort( function( a, b) { return bigtosmall ? parseFloat( b) - parseFloat( a) : parseFloat( a) - parseFloat( b)})}
$.hlsort = function( hl, k, bigtosmall) { // returns new hash -- values have to be numbers
	var ks = $.hk( hl); 
	var vs = $.hltl( hl, k); for ( var i in vs) if ( $.isString( vs[ i])) vs[ i] = parseFloat( '' + vs[ i]); 
	var v2k = {}; for ( var i in vs) { var k = ks[ i]; var v = '' + vs[ i]; if ( ! v2k[ v]) v2k[ v] = []; v2k[v].push( k); }
	$.lsort( vs, bigtosmall);
	//$.log( 'vs', $.ltt( vs));
	var hl2 = []; 
	for ( var i in vs) { var v = vs[ i]; for ( var ii in v2k[ '' + v]) { var k = v2k[ '' + v][ ii];  hl2.push( hl[ k]); }}
	return hl2;
}


// text dimensions, returns { height, width}
$.textdim = function( text, css) {
	var $dummy = $( 'body').ioover( $.hm({ position: 'absolute', right: '-10px', top: '0px', width: 'auto', height: 'auto'}, css))
	.append( text);
	var h = { height: $dummy.height(), width: $dummy.width()};
	$dummy.remove();
	return h;
}
$.strim = function( text) { // trim string
	var list = $.s2l( text, ' ', null, true);
	if ( ! list.length) return '';
	return $.l2s( list, ' ');
}
$.strmailto = function( email, subject, body) { // return mailto URL -- make sure it does not exceed 10?? bytes
	var text = email + '?subject=' + subject + '&body=' + body;
	var setup = { '://': '%3A%2F%2F', '/': '%2F', ':': '%3A', ' ': '%20', ',': '%2C', "\n": '%0A', '=': '%3D', '&': '%26', '#': '%23', '"': '%22'}
	for ( var k in setup) text = $.l2s( $.s2l( text, k), setup[ k]);
	return text;
}

// math
$.mathMin = function( list) {
	if ( ! list || ! list.length) return 0;
	var min = null;
	for ( var i = 0; i < list.length; i++) {
		if ( min === null) min = list[ i];
		if ( list[ i] < min) min = list[ i];
	}
	return min;
}
$.mathMax = function( list) {
	if ( ! list || ! list.length) return 0;
	var max = null;
	for ( var i = 0; i < list.length; i++) {
		if ( max === null) max = list[ i];
		if ( list[ i] > max) max = list[ i];
	}
	return max;
}
$.mathAvg = function( list, round) {
	if ( ! list || ! list.length) return 0;
	var sum = 0;
	for ( var i = 0; i < list.length; i++) sum += $.isNumber( list[ i]) ? list[ i] : parseFloat( list[ i]);
	return round ? Math.round( sum / list.length) : sum / list.length;
}
$.mathRound = function( number, round) { // default round = 0
	if ( ! round) round = 0;
	var s = '' + number;
	if ( $.s2l( s, '.').length == 1) return number;
	var L = $.s2l( s, '.');
	if ( ! round) L.pop();
	else L[ 1] = L[ 1].substr( 0, round);	// leave only that number of digits
	return parseFloat( $.l2s( L, '.'));
}
// used for all canvas calculations, returns frame object
$.mathScaleFrame = function( inprops) {
	var props = $.hr({
		width				: 100,
		height				: 100,
		margintop			: 5,
		marginleft			: 5,
		marginbottom	: 5,
		marginright		: 5,
		xmin 				: 0,
		xmax				: 100,
		ymin					: 0,
		ymax				: 100
	}, inprops);
	var frame = {};
	frame.props = props;
	frame.scalex = function( x) {
		var temp = x - this.props.xmin;
		temp /= this.props.xmax - this.props.xmin;
		temp *= this.props.width - this.props.marginleft - this.props.marginright;
		temp += this.props.marginleft;
		return temp;
	}
	frame.scaley = function( y) {
		return this.props.height - this.props.marginbottom 
		- ( ( y - this.props.ymin) / ( this.props.ymax - this.props.ymin)) 
		* ( this.props.height - this.props.margintop - this.props.marginbottom);
	}
	// margins
	frame.marginTop = function() { return this.props.margintop; }
	frame.marginRight = function() { return this.props.marginright; }
	frame.marginBottom = function() { return this.props.marginbottom; }
	frame.marginLeft = function() { return this.props.marginleft; }
	// helpful functions
	frame.lowx = function() { return this.props.marginleft; }
	frame.highx = function() { return this.props.width - this.props.marginright; }
	frame.lowy = function() { return this.props.height - this.props.marginbottom; }
	frame.highy = function() { return this.props.margintop; }
	return frame;
}
$.mathCurveSlowUpFastDown = function( value, count) { 	// returns smaller values based on the count
	var list = [];
	var range = 2;
	var skew = 0.3;
	var shift = 0;
	var q = range / skew;
	var u = shift;
	var step = 30 / count;		// arbitrary rnage
	var sum = 0;
	var min = null;
	for ( var i = -20; i <= 10; i += step) {
		var one = ( 1 / ( q * Math.sqrt( 2 * 3.14)));
		var two = Math.pow( i - u, 2);
		var three = 2 * Math.pow( q, 2);
		var four = Math.exp( - two / three);
		var five = Math.exp( four);
		var sample =  one * five;
		if ( min === null) min = sample;
		if ( sample < min) min = sample;
		list.push( sample);
	}
	for ( var i = 0; i < list.length; i++) {
		list[ i] = list[ i] - min;
		sum += list[ i];
	}
	for ( var i = 0; i < list.length; i++) {
		list[ i] = value * ( list[ i] / sum);
	}
	return list;
}
$.mathRandom = function( length) {
	if ( ! length) length = 10;
	var out = '';
	for ( var i = 0; i < length; i++) {
		out +=  '' + Math.round( Math.random() * 10) + '';
	}
	return out;
}
$.mathRandomInt = function( min, max) {  return min + Math.floor( Math.random() * ( max - min)); }
$.mathShuffle = function( o) {
	for ( var j, x, i = o.length; i; j = parseInt( Math.random() * i), x = o[--i], o[ i] = o[ j], o[ j] = x);
	return o;
}
// returns list of value starting at FROM and ending in TO   values are real, not relative
$.mathCurve = function( from, to, speed) { // speed:  fast: 5 steps/50%   normal: 10steps/30%   slow: 20steps/20%
	if ( ! speed) speed = 'normal';
	// infer how many decimal numbers you need
	var L = []; 
	var L2 = $.s2l( '' + from, '.'); L.push( L2.length == 2 ? L2[ 1].length : 0);
	L2 = $.s2l( '' + to, '.'); L.push( L2.length == 2 ? L2[ 1].length : 0);
	decimals = $.mathMax( L) + 1;
	//$.log( 'mathCurve() : from/to/decimals/L:', from, to, decimals, L);
	from = parseFloat( '' + from); two = parseFloat( '' + to);
	var c1 = 1; var c2 = 1; for ( var i = 0; i < decimals; i++) { c1 *= 10; c2 /= 10; }	// for rounding numbers up
	//$.log( 'mathCurve() : c1/c2 : ', c1, c2);
	var setup = { 'fast': [ 5, 0.5], 'normal': [ 10, 0.3], 'slow': [ 20, 0.2]}; // [ how many steps, reduction in each step]
	var diff = to - from;
	L = [ from];
	for ( var i = 0; i < setup[ speed][ 0] - 1; i++) {
		var diff2 = diff * ( 1 - setup[ speed][ 1]);
		from += diff - diff2; diff = diff2;
		from = Math.round( c1 * from) / c1;	// round up to the (decimals) digits
		L.push( from);
	}
	L.push( to);
	//$.log( 'mathCurve()', L);
	return L;
}
// rotations
$.mathRotate = function( r, a) { 	// r: radius, a: angle -- rotate ( r, 0) to ( x, y), returns { x, y}
	var h = {};
	while ( a > 360) a -= 360;
	var cos = Math.cos( 2 * 3.14159265 * ( a / 360));
	h.x = Math.round( r * cos);
	h.y = Math.round( Math.sqrt( Math.pow( r, 2) - Math.pow( h.x, 2)));
	if ( a > 180) h.y = - h.y;
	return h;
}


// dom manipulations
$.domWrapInner = function( dom, relative) { // returns inner div dom
	var $inner = $( '<div style="position:absolute;top:0px;left:0px;width:100%;height:100%;"></div>');
	if ( relative) $inner.css( 'position', 'relative');
	$inner.append( $( dom).contents());
	$( dom).append( $inner);
	return $inner.get( 0);
}
$.domIsEmpty = function( dom) {
	var kids = $( dom).children().get();
	if ( ! kids.length) return true;
	return false;
}
$.domAvoidZeroSize = function( dom) {
	if ( $( dom).width() == 0) $( dom).css( 'width', '10em');
	if ( $( dom).height() == 0) $( dom).css( 'height', '1.4em');
}
$.domPopup = function( title, url, x, y, w, h) {
	if ( ! x) x = Math.round( Math.random() * 400 + 10);
	if ( ! y) y = Math.round( Math.random() * 300 + 10);
	if ( ! w) w = 500;
	if ( ! h) h = 500;
	return window.open( url, name, 'top=' + y + ',left=' + x + ',width=' + w + ',height=' + h + ',resizable,scrollbars');
}
// return hash( width, height) of your size relative (%) to your parent
$.domGetRelSize = function( what) { return { // returns { width, height, top, left} -- all int percentages
	"width": Math.round( 100 * ( what.width() / what.parent().width())),
	"height": Math.round( 100 * ( what.height() / what.parent().height())),
	"top": Math.round( 100 * ( what.position().top / what.parent().height())),
	"left": Math.round( 100 * ( what.position().left / what.parent().width()))
}}
$.domGetPagePos = function( $dom) {	// global left, top of this box
	var $box = $dom;
	var POS = $box.position();	// left, top
	while ( $box.parent().isindom() && $box.parent().get( 0).tagName != 'body' && $box.parent().get( 0).tagName != 'BODY') {
		$box = $box.parent();
		var pos = $box.position();
		POS.left += pos.left;
		POS.top += pos.top;
	}
	for ( var k in POS) POS[ k] = Math.round( POS[ k]);
	return POS;
}

$.rurl = function( url, length) { 
	if ( ! length) return url; 
	if ( ! url || ! $.isString( url)) return url;
	if ( url.indexOf( '?') !== -1) url += '&';
	else url += '?';
	return url + $.mathRandom( length); 
}
$.curl = function( actions, random, burl) { return $.rurl( ( burl ? burl : $.io.burl) + '/' + ( actions ? actions : 'actions.php'), random ? 10 : 0); }
$.changeurl = function( url) { var one = function() { 
	var $box = $( 'body').ioover({ position: 'absolute', right: '101%', width: '10px'});
	var $form = $box.ioover({}, 'form', { action: $.rurl( url, 5), name: 'redirectform'});
	$form.submit();   
	$box.stopTime().oneTime( '1s', function() { })
}; eval( one)(); }
$.jsload = function( url, call, timeoutc) { var one = function( counter) { 
	//console.log( 'jsload()  trying ... counter/timeout', counter, url);
	if ( counter-- < 0) { if ( timeoutc) eval( timeoutc)(); return; }
	var stats = { type: 'ioutils.jsload', time: $.iotime()}
	var $box = $( 'body').ioover({ position: 'absolute', right: '101%', width: '10px'})
	$box.stopTime().oneTime( '2s', function() { $box.remove(); eval( one)( counter); })
	return $.getScript( $.rurl( url), function() { 
		$box.stopTime(); $box.remove();
		//console.log( 'script loaded OK', url);
		if ( $.ioutils.stats) $.ioutils.stats.push( stats);
		if ( call) eval( call)();
	});
	
}; eval( one)( 5); }
$.jsloadbytag = function( url) {
	var script = document.createElement( "script");
	script.src = $.rurl( url, 5);
	var head = document.getElementsByTagName("head")[0];    
	head.appendChild( script);
	return script;
}
$.jsonload = function( url, one, two, three, four, five) {	// url, [timeout,method,failhash,c] 
	var method = 'post'; var c = null; var http = {}; 
	var timeout = $.ioutils.callbacktimeout; var failhash = { errs: 'jsonload() timeouted of bad data format'};
	if ( one) { c = one; }
	if ( two) { http = one; c = two; }
	if ( three) { http = one; timeout = two; c = three; }
	if ( four) { http = one; timeout = two; method = three; c = four; }
	if ( five) { http = one; timeout = two; method = three; failhash = four; c = five; }
	if ( $.hk( http).length && ! http.rand) http.rand = $.mathRandom( 5);
	else url = $.rurl( url, 5);
	// if stats is on, create httpid object with short summary of this request
	var http2 = {}; if ( http && ! $.ioutils.nostats) for ( var k in http) if ( ( $.isString( http[ k]) && http[ k].length < 100) || $.isNumber( http[ k]) || $.isBoolean( http[ k])) http2[ k] = http[ k];
	var stats = { type: 'ioutils.jsonload', url: url, method: method, http: http2, timeout: timeout, time: $.iotime()}
	// if jsonsession is set, add session
	if ( $.ioutils.jsonsession && $.io.session) http.ss = $.s2s64( $.toJSON( $.io.session));
	// control by timeout
	var $box = $( 'BODY').ioover().css({ width: '1px', height: '1px'})
	if ( method == 'post') $.post( url, http, function( json) { 
		if ( $box.isindom()) $box.stopTime().remove(); 
		if ( c) eval( c)( json); 
		stats[ status] = json ? ( c ? 'ok' : 'ok.late') : 'nok';
		$.ioutils.stats.push( stats);
	}, 'json');
	else $.get( url, http, function( json) { 
		if ( $box.isindom()) $box.stopTime().remove(); 
		if ( c) eval( c)( json && $.hk( json).length ? json : failhash); // json=NULL when/if timeouted
		stats[ status] = json ? ( c ? 'ok' : 'ok.late') : 'nok';
		$.ioutils.stats.push( stats);
	}, 'json');
	$box.oneTime( parseInt( '' + timeout) + 's', function() {
		if ( $box.isindom()) $box.stopTime().empty().remove();
		if ( ! $.ioutils.nolog) $.log( 1, 'JSONLOAD ERROR: timeout[' + timeout + ']s passed, but no data recieved, return FAILHASH, url/http:', url, http);
		eval( c)( failhash); c = null; // make sure this callback is not used again
		stats[ status] = 'timeout';
		$.ioutils.stats.push( stats);
	})
	
}
$.jsonloadold = function( url, one, two, three, four, five) {	// same as above, but uses eval() method 
	var method = 'post'; var c = null; var http = {}; 
	var timeout = 5; var failhash = { errs: 'json load/parse error'};
	if ( one) { c = one; }
	if ( two) { http = one; c = two; }
	if ( three) { http = one; timeout = two; c = three; }
	if ( four) { http = one; timeout = two; method = three; c = four; }
	if ( five) { http = one; timeout = two; method = three; failhash = four; c = five; }
	url = $.rurl( url, 5);	// randomize regardless
	// control by timeout
	var $box = $( 'BODY').ioover().css({ width: '1px', height: '1px'})
	$box.oneTime( timeout + 's', function() {
		$box.remove();
		$.log( 1, 'JSONLOAD ERROR: timeout[' + timeout + ']s passed, but no data recieved, return FAILHASH');
		eval( c)( failhash);
	})
	if ( method == 'post') $.post( url, http, function( json) { 
		//$.log( 5, ' : jsonloadold: got text (POST)');
		var props = eval( '(' + json + ')');
		//$.log( 5, ' : jsonloadold: eval OK:', props);
		$box.stopTime().remove();
		if ( c) eval( c)( props); 
	}, 'text');
	else $.get( url, http, function( json) { 
		//$.log( 5, ' : jsonloadold: got text (GET)');
		var props = eval( '(' + json + ')');
		//$.log( 5, ' : jsonloadold: eval OK:', props);
		$box.stopTime().remove();
		if ( c) eval( c)( props); 
	}, 'text');
}
$.blobload = function( url, c, type) { // type example: image/png, returns Blob
	var xhr = new XMLHttpRequest();
	xhr.open( 'GET', $.rurl( url, 5), true);
	xhr.responseType = 'blob';
	xhr.onload = function(e) {
		if ( this.status !== 200) return eval( c)( null);
		var blob = new Blob( [ this.response], { type: type});
		eval( c)( blob);
	}
	xhr.send();
}
$.arraybufferload = function( url, c) { var one = function( counter) { 
	if ( counter-- < 0) return eval( c)( null);
	var xhr = null;
	try { xhr = new XMLHttpRequest(); }
	catch ( e) { return eval( one)( counter); }
	xhr.open( 'GET', $.rurl( url, 5), true);
	xhr.responseType = 'arraybuffer';
	xhr.onload = function( e) {
		//$.log( this);
		//$.log( e);
		if ( this.status !== 200) return eval( one)( counter);
		var data
		try { data = new Uint8Array( this.response); eval( c)( data); }
		catch ( e) { console.log( 'arraybufferload() error', e); return eval( one)( counter); }
	}
	xhr.onerror = function( e) { return eval( one)( counter); }
	xhr.send();
}; eval( one)( 5); }
// will call a URL expecting it to be a JS script, which should call callback( data) when done, or will timeout otherwise
$.jsremote = function( url, http, c, timeout, b64json) {	// needs var callback in global scope,  eval( c)( null) if failed
	var stats = { type: 'ioutils.jsremote', time: $.iotime(), url: url, http: http, timeout: timeout}
	callback = function( data)  {
		callback = null;
		$( 'body').stopTime();
		eval( c)( data === null ? data : ( b64json && data ? $.json2h( data, true) : data));	// could be null, or official data
		stats.status = 'ok'; if ( $.ioutils.stats) $.ioutils.stats.push( stats);
	}
	if ( ! timeout) timeout = $.ioutils.callbacktimeout;	// global variable
	var del = '?'; if ( http) for ( var k in http) { url += del + k + '=' + http[ k]; del = '&'; }
	$.jsloadbytag( $.rurl( url, 5));
	$( 'body').stopTime().oneTime( timeout, function() { 
		if ( callback) eval( callback)( null); callback = null;	// do not tell it be called again
		stats.status = 'timeout'; if ( $.ioutils.stats) $.ioutils.stats.push( stats)
	})
	
}
$.jsvoid = function() {}

