// web.js
var http = require( 'http');
var fs = require( 'fs');
var express = require( 'express');
var logfmt = require( 'logfmt');
var app = express();
app.get( '/', function( req, rep) { http.get({ host: 'cloudq9test.herokuapp.com', path: '/?action=show'}, function( rep2) { 
	var s = '';
	rep2.on( 'data', function( s2) { s += s2; })
	rep2.on( 'end', function() { rep.send( s); })
}).end(); });
app.listen( process.env.PORT, function() {});