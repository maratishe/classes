var http = require( 'http');
var fs = require( 'fs');
var express = require( 'express');
var logfmt = require( 'logfmt');
var app = express();
app.get( '/', function( req, rep) { rep.send( 'I am here!'); })
app.listen( process.env.PORT, function() {});