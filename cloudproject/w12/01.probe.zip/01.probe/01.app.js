$( document).ready( function() { 
	var $body = $( 'body').css({ 'font-size': $.io.defs.fonts.large})
	$body.ioover( true).append( 'date,time,bytes,time');
	var one = function() { 
		var before = $.iotime(); var date = $.tets( before, true); var time = $.tets( before, false, true); var $box = $body.ioover( true);
		$box.append( date + ',' + time);
		$.get( 'http://cloudq9test.herokuapp.com', { rand: $.mathRandom( 10)}, function( text) { 
			var took = $.iotime() - before;
			$box.append( ',' + took); 
		}, 'text');
		
	}
	for ( var i = 0; i < 10; i++) one(); // parallel, but callbacks are sequential
})
