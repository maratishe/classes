git add . -A
git add -u
git commit -am upload
git push heroku master