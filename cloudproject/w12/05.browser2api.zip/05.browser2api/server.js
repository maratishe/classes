var http = require( 'http');
var fs = require( 'fs');
var express = require( 'express');
var logfmt = require( 'logfmt');
var app = express();
app.get( '/', function( req, rep) { 
	if ( ! req.query || ! req.query.file) return fs.readFile( './index.html', 'utf8', function( err, text) { rep.send( text); })
	if ( req.query && req.query.file) return fs.readFile( './' + req.query.file, 'utf8', function( err, text) { rep.send( text); })
	
})
app.listen( process.env.PORT, function() {});