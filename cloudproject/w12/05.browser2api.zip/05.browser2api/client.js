$( document).ready( function() { 
	$( 'body').append( 'OK');
})