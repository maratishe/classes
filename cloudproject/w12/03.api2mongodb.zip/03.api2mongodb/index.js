// web.js
//var $, window;
//var jsdom = require( 'jsdom');
var fs = require( 'fs');
var express = require( 'express');
var logfmt = require( 'logfmt');
var mongo = require( 'mongodb'); var MURL = process.env.MONGOHQ_URL;
var app = express();
app.use( logfmt.requestLogger());
app.get( '/', function( req, rep) { 	// name, aff, email
	if ( req.query && req.query.action && req.query.action == 'add') { // add
		mongo.Db.connect( MURL, function( err, db) { 
			db.collection( 'tem', function( err2, table) { 
				table.insert({ msg: 'I am here at ' + ( new Date()).toDateString()}, { safe: true}, function( err3, rs) { 
					rep.send( JSON.stringify( { msg: 'OK'}));
				});
			});
		});
	}
	if ( req.query && req.query.action && req.query.action == 'show') { // add
		mongo.Db.connect( MURL, function( err, db) { 
			db.collection( 'tem', function( err2, table) { 
				table.find({}).toArray( function( err3, docs) { 
					rep.send( JSON.stringify( docs));
				});
			});
		});
		
	}
	
})
var port = Number( process.env.PORT || 5000);
app.listen( port, function() { console.log( 'Listening on ' + port); })
